from setuptools import setup

setup(
    name='mylib',
    version='0.0.1',
    description='a pip-installable package example',
    license='MIT',
    packages=['mylib'],
    author='Fabricio Silva',
    author_email='fabricioadenir@gmail.com',
    keywords=['example'],
    url='https://github.com/fabricioadenir/teste-libraries'
)
