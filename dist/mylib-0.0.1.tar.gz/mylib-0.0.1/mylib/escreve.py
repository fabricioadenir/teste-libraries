def escrever(palavra):
    print(f"Palavra escrita: {palavra}")
    return True
